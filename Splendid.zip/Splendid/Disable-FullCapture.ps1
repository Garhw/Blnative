<#
    Disable-FullCapture.ps1   ***RUN AS ADMINISTRATOR***
    Reverses Setup-FullCapture.ps1. Existing logs are kept.
#>
$ErrorActionPreference = 'SilentlyContinue'
# all-users Clink autorun
$clinkExe = Join-Path $PSScriptRoot 'clink\clink_x64.exe'
if (Test-Path $clinkExe) { & $clinkExe autorun uninstall --allusers | Out-Null }
Remove-Item 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging' -Recurse -Force
Remove-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Audit' `
    -Name ProcessCreationIncludeCmdLine_Enabled -Force
auditpol /set /subcategory:"Process Creation" /success:disable /failure:disable | Out-Null

# Remove the loader line from the all-users profile
$allProfile = $PROFILE.AllUsersAllHosts
if (Test-Path $allProfile) {
    (Get-Content $allProfile) | Where-Object { $_ -notmatch 'CommandLogger\.ps1' } |
        Set-Content -LiteralPath $allProfile -Encoding UTF8
}
Write-Host 'Full capture disabled (all-users). Existing logs kept.' -ForegroundColor Yellow
Write-Host 'To also remove your per-user logger, edit:' $PROFILE.CurrentUserAllHosts
