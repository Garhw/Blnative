============================================================
  Splendid  -  command / input recorder for Windows
============================================================

WHAT IT DOES
------------
Once installed, Splendid quietly records every command line entered
on this PC and stays on by itself after every restart. It captures:

  * Everything typed into Command Prompt (cmd), including built-ins
    like dir / cd / set.
  * Everything typed or pasted into PowerShell.
  * Every program launched from any shell - including a shell opened
    by a remote tool (remote terminal / "SYSTEM" shell).

It saves only the COMMAND TEXT (not the output) to a plain .txt file.
Nothing is sent anywhere over the internet.

PLEASE NOTE: this is a monitoring tool. Only install it on a
computer that you own, or with the clear knowledge and agreement of
the person who uses it. Recording someone secretly can be illegal.


HOW TO INSTALL  (one time, ~30 seconds)
---------------------------------------
1. Put this whole "Splendid" folder on the C: drive, so it sits at:
        C:\Splendid
   (You can download/unzip it anywhere first, but MOVE it to
    C:\Splendid before step 2. Do NOT leave it in Downloads.)

2. Open the folder and DOUBLE-CLICK:   INSTALL.cmd

3. A blue Windows box asks for permission. Click YES.

4. Wait until it says "Setup finished", then close the window.

IMPORTANT: after installing, do NOT move, rename, or delete this
folder. Windows loads the recorder from C:\Splendid every time, so
it must stay exactly there.

That's it. Recording is now ON for the whole PC and turns itself
back on automatically after every restart.


HOW TO SEE THE RECORDED COMMANDS
--------------------------------
* DOUBLE-CLICK:  SHOW-COMMANDS.cmd
     - Click YES on the permission box.
     - It lists the commands and saves them to a text file:
            C:\Splendid\commands.txt
     - That file is replaced with fresh results each time you run it.

* DOUBLE-CLICK:  OPEN-LOG.cmd
     - Opens C:\Splendid\commands.txt in Notepad (no popup).


CHOOSE HOW FAR BACK IT LOOKS
----------------------------
* DOUBLE-CLICK:  SET-TIME.cmd
     - Pick a range: 20 min / 1 hour / 6 hours / 24 hours /
       7 days / everything / a custom number of minutes.
     - SHOW-COMMANDS uses that range from then on, and it stays
       set until you run SET-TIME.cmd again.


HOW TO TURN IT OFF
------------------
* DOUBLE-CLICK:  UNINSTALL.cmd  ->  click YES.
  Recording stops for the whole PC. Saved logs are kept.


WHAT'S IN THIS FOLDER
---------------------
  INSTALL.cmd            Turn recording ON (one-click, asks permission)
  SHOW-COMMANDS.cmd      View the recorded commands + save the text file
  OPEN-LOG.cmd           Reopen the saved text log
  SET-TIME.cmd           Choose how far back to look
  UNINSTALL.cmd          Turn recording OFF
  clink\                 The cmd.exe recorder engine
  *.ps1                  The PowerShell recorder + setup scripts

Don't rename the files inside this folder - they call each other by
name, so renaming them breaks the tool.
============================================================
