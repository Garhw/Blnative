<#
    CommandLogger.ps1  -- the actual capture engine.

    Dot-sourced from a PowerShell profile. On every command you submit in an
    interactive PowerShell session it writes the EXACT input line (all
    characters, quotes, variables, spacing) to a log file. Input only - never
    the output. Completely silent in the session.

    No administrator rights required. Works via PSReadLine's history handler,
    which fires once per submitted command line.
#>

# --- pick a writable, discreet log location ----------------------------------
function Get-CmdAuditLogFile {
    $candidates = @(
        (Join-Path $env:ProgramData  'CommandAudit'),   # machine-wide (needs rights)
        (Join-Path $env:LOCALAPPDATA 'CommandAudit')    # per-user fallback
    )
    foreach ($dir in $candidates) {
        try {
            if (-not (Test-Path $dir)) {
                New-Item -ItemType Directory -Path $dir -Force -ErrorAction Stop | Out-Null
            }
            $probe = Join-Path $dir '.probe'
            Set-Content -LiteralPath $probe -Value '' -ErrorAction Stop
            Remove-Item -LiteralPath $probe -Force -ErrorAction SilentlyContinue
            return (Join-Path $dir 'input.log')
        } catch { continue }
    }
    # last resort
    return (Join-Path $env:TEMP 'CommandAudit_input.log')
}

$Global:CmdAuditLogFile = Get-CmdAuditLogFile

# --- the core writer (kept as its own function so it is directly testable) ---
function Write-CmdAuditEntry {
    param(
        [Parameter(Mandatory)][AllowEmptyString()][string]$Line,
        [string]$LogFile = $Global:CmdAuditLogFile
    )
    if ([string]::IsNullOrEmpty($Line)) { return }   # skip blank submissions
    $ts    = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $entry = "[$ts] [user=$env:USERNAME host=$env:COMPUTERNAME pid=$PID] $Line"

    # Global mutex -> safe when several remote sessions log at once.
    $mtx = New-Object System.Threading.Mutex($false, 'Global\CmdAuditMutex')
    [void]$mtx.WaitOne()
    try {
        Add-Content -LiteralPath $LogFile -Value $entry -Encoding UTF8
    } finally {
        $mtx.ReleaseMutex(); $mtx.Dispose()
    }
}

# --- hook every submitted command line ---------------------------------------
if (Get-Module PSReadLine) {
    Set-PSReadLineOption -AddToHistoryHandler {
        param($line)
        try { Write-CmdAuditEntry -Line $line } catch { }
        return $true      # keep normal history behaviour
    }
}
