@echo off
REM ============================================================
REM  Splendid - one-click installer (self-elevates via UAC)
REM  Turns on capture of every command run on this PC, including
REM  the SYSTEM shell opened by the remote (dw) console.
REM ============================================================
title Splendid Installer

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting administrator rights...
    powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

echo Running setup as administrator...
echo.
powershell -ExecutionPolicy Bypass -File "%~dp0Setup-FullCapture.ps1"
echo.
echo ============================================================
echo  Setup finished. You can close this window.
echo  From now on, use  SHOW-COMMANDS.cmd  to see what was typed.
echo ============================================================
echo.
pause
