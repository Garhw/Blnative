<#
    Get-CapturedCommands.ps1
    Shows the commands recorded on THIS machine (programs launched in any shell,
    including the remote SYSTEM shell), newest last.

    Sources:
      [CMD]/[PS] text logs  (Clink / PowerShell loggers, when a real console)
      Event 4688            (every program launched - needs admin to read)
#>
[CmdletBinding()]
param([int]$Minutes = -1)   # -1 = use the range saved by SET-TIME.cmd; 0 = all time

# --- use the saved time range (SET-TIME.cmd) when none was passed -------------
if ($Minutes -lt 0) {
    $Minutes = 20   # default if nothing has been set yet
    foreach ($cfg in @((Join-Path $env:LOCALAPPDATA 'CommandAudit\view_minutes.txt'),
                       (Join-Path $PSScriptRoot 'view_minutes.txt'))) {
        try {
            if (Test-Path -LiteralPath $cfg) {
                $raw = ([string](Get-Content -LiteralPath $cfg -TotalCount 1)).Trim()
                if ($raw -match '^\d+$') { $Minutes = [int]$raw; break }
            }
        } catch { }
    }
}

# --- elevation check (reading the Security log requires admin) ----------------
$id = [Security.Principal.WindowsIdentity]::GetCurrent()
$isAdmin = (New-Object Security.Principal.WindowsPrincipal($id)).IsInRole(
             [Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "NOT running as administrator - the cmd/SYSTEM command log lives in" -ForegroundColor Yellow
    Write-Host "the Windows Security log, which only opens with admin rights." -ForegroundColor Yellow
    Write-Host "Use SHOW-COMMANDS.cmd (it self-elevates) or run this from an admin PowerShell.`n" -ForegroundColor Yellow
}

$rangeText = if ($Minutes -le 0) { 'ALL recorded commands' } else { "the last $Minutes minutes" }
Write-Host ("Reading {0}..." -f $rangeText) -ForegroundColor Cyan
$rows = New-Object System.Collections.Generic.List[object]

# --- text logs (Clink cmd logger + PowerShell logger) ------------------------
$textLogs = @(
    @{ Kind='PS '; Path=(Join-Path $env:ProgramData  'CommandAudit\input.log') },
    @{ Kind='PS '; Path=(Join-Path $env:LOCALAPPDATA 'CommandAudit\input.log') },
    @{ Kind='CMD'; Path=(Join-Path $env:ProgramData  'CommandAudit\cmd_input.log') },
    @{ Kind='CMD'; Path=(Join-Path $env:LOCALAPPDATA 'CommandAudit\cmd_input.log') }
)
$cutoff = if ($Minutes -gt 0) { (Get-Date).AddMinutes(-$Minutes) } else { [datetime]::MinValue }
foreach ($src in $textLogs) {
    try {
        if (Test-Path -LiteralPath $src.Path -ErrorAction Stop) {
            foreach ($ln in Get-Content -LiteralPath $src.Path -ErrorAction Stop) {
                if ($ln -match '^\[(?<t>[^\]]+)\]\s\[user=(?<u>[^\s]+)[^\]]*\]\s(?<c>.*)$') {
                    $t = [datetime]::ParseExact($matches.t,'yyyy-MM-dd HH:mm:ss',$null)
                    if ($t -ge $cutoff) {
                        $rows.Add([pscustomobject]@{
                            Time = $t; Kind = $src.Kind; User = $matches.u; Command = $matches.c })
                    }
                }
            }
        }
    } catch { }
}

# --- Event 4688: every program launched from a shell -------------------------
# The recorder's OWN helper processes also get audited (Clink injecting, the
# 'net session' admin check, the self-elevation, and this viewer script). Those
# are just the tool working - hide them so only real commands show.
$selfNoise = 'clink_(x64|x86|arm64|dll)|clink\.bat|\binject\b|\bautorun\b|' +
             'net\s+session|Start-Process\s+cmd\s+-Verb\s+RunAs|auditpol|' +
             'Get-CapturedCommands\.ps1|Setup-FullCapture\.ps1|Disable-FullCapture\.ps1|' +
             'CommandLogger\.ps1|SHOW-COMMANDS\.cmd|INSTALL\.cmd|UNINSTALL\.cmd|OPEN-LOG\.cmd'

$filter = @{ LogName='Security'; Id=4688 }
if ($Minutes -gt 0) { $filter.StartTime = (Get-Date).AddMinutes(-$Minutes) }
try {
    # -MaxEvents keeps it fast (no more endless "loading").
    Get-WinEvent -FilterHashtable $filter -MaxEvents 500 -ErrorAction Stop | ForEach-Object {
        $x = [xml]$_.ToXml(); $d = @{}
        $x.Event.EventData.Data | ForEach-Object { $d[$_.Name] = $_.'#text' }
        $parent = [string]$d['ParentProcessName']
        $cmdline = [string]$d['CommandLine']
        # Keep commands launched from a shell; skip conhost + the tool's own noise.
        if ($parent -match '\\(cmd|powershell|pwsh)\.exe$' -and $cmdline -and
            $cmdline -notmatch 'conhost\.exe' -and $cmdline -notmatch $selfNoise) {
            $rows.Add([pscustomobject]@{
                Time = $_.TimeCreated; Kind = 'CMD'; User = $d['SubjectUserName']; Command = $cmdline })
        }
    }
} catch {
    if ($isAdmin) { Write-Host "[i] No matching Security-log entries in this window." -ForegroundColor DarkYellow }
}

if ($rows.Count -eq 0) {
    Write-Host "`nNothing to show. If you expected results, make sure you ran this elevated (SHOW-COMMANDS.cmd)." -ForegroundColor Yellow
    return
}

$sorted = $rows | Sort-Object Time

# Save a plain-text copy INTO the CommandAudit folder (next to this script).
# Set-Content overwrites, so the file always holds ONLY the latest run's
# results; the previous file simply sits there until the next SHOW-COMMANDS.
$textOut = $sorted | ForEach-Object { "[{0}] [{1}] {2}" -f $_.Time.ToString('yyyy-MM-dd HH:mm:ss'), $_.User, $_.Command }
foreach ($tp in @((Join-Path $PSScriptRoot 'commands.txt'),
                  (Join-Path $env:LOCALAPPDATA 'CommandAudit\commands.txt'))) {
    try { Set-Content -LiteralPath $tp -Value $textOut -Encoding UTF8 -ErrorAction Stop
          Write-Host ("Saved to text file: {0}" -f $tp) -ForegroundColor Green; break } catch { }
}

Write-Host ("`n{0} commands recorded:`n" -f $rows.Count) -ForegroundColor Green
$sorted | Format-Table @{L='Time';E={$_.Time.ToString('MM-dd HH:mm:ss')}}, Kind, User, Command -AutoSize -Wrap
