@echo off
REM ============================================================
REM  Splendid - one-click uninstaller (self-elevates via UAC)
REM  Turns recording back OFF for the whole PC. Existing logs are kept.
REM ============================================================
title Splendid Uninstaller

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting administrator rights...
    powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

echo Turning command recording off...
echo.
powershell -ExecutionPolicy Bypass -File "%~dp0Disable-FullCapture.ps1"
echo.
echo ============================================================
echo  Recording is now OFF. You can close this window.
echo ============================================================
echo.
pause
