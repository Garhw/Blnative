-- command_logger.lua  (CommandAudit) -- machine-wide location (binaries dir).
-- Silently records EVERY command line entered in cmd.exe, exactly as typed,
-- including built-ins (dir/cd/set/echo). Input only. Loaded by Clink for ANY
-- user (including SYSTEM) because the binaries dir is always on the script path.

-- Prefer a shared machine-wide folder so SYSTEM + interactive users all land in
-- one log; fall back to the per-user folder when ProgramData isn't writable.
local function pick_logfile()
    local pd = os.getenv("ProgramData")
    if pd then
        local d = pd .. "\\CommandAudit"
        local probe = io.open(d .. "\\cmd_input.log", "a")
        if probe then probe:close(); return d .. "\\cmd_input.log" end
    end
    local la = os.getenv("LOCALAPPDATA") or os.getenv("TEMP") or "C:\\Temp"
    local d = la .. "\\CommandAudit"
    os.execute('mkdir "' .. d .. '" >nul 2>nul')
    return d .. "\\cmd_input.log"
end

local LOGFILE = pick_logfile()

local function write_log(line)
    if not line or line == "" then return end   -- skip blank Enter presses
    local ts   = os.date("%Y-%m-%d %H:%M:%S")
    local user = os.getenv("USERNAME")     or "?"
    local host = os.getenv("COMPUTERNAME") or "?"
    local f = io.open(LOGFILE, "a")
    if f then
        f:write("[" .. ts .. "] [user=" .. user .. " host=" .. host .. " pid=cmd] " .. line .. "\n")
        f:close()
    end
end

-- Exposed so the self-test can call the writer directly.
_G.__cmdaudit_write = write_log

-- Live hook: fires once per command line accepted in interactive cmd.exe.
if clink and clink.onendedit then
    clink.onendedit(write_log)
end
