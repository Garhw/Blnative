<#
    Setup-FullCapture.ps1   ***RUN AS ADMINISTRATOR*** (one time)

    Makes command capture work for EVERY account, including the SYSTEM shell
    that a remote tool like 'dw' opens. Turns on, for both cmd.exe and
    PowerShell:

      RELIABLE (works even if the remote shell uses pipes, not a real console):
        * Process Creation auditing  -> Event 4688 : exact command line of every
          program launched (covers external commands run in cmd or PowerShell).
        * PowerShell Script Block Logging -> Event 4104 : text of PS commands.

      BONUS (exact typed input incl. cmd built-ins, when the shell IS a real
             console):
        * Clink autorun for ALL users -> logs every cmd.exe input line.
        * Machine-wide PowerShell profile -> logs every PS input line.

    All silent. Reverse with Disable-FullCapture.ps1.
#>
[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'

$id = [Security.Principal.WindowsIdentity]::GetCurrent()
if (-not (New-Object Security.Principal.WindowsPrincipal($id)).IsInRole(
        [Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run this in an ELEVATED PowerShell (Run as administrator).'
}
$clinkDir = Join-Path $PSScriptRoot 'clink'
$clinkExe = Join-Path $clinkDir 'clink_x64.exe'
$engine   = Join-Path $PSScriptRoot 'CommandLogger.ps1'
$lua      = Join-Path $clinkDir 'command_logger.lua'

# --- 0. Shared machine-wide log folder that ALL accounts can write to --------
$shared = Join-Path $env:ProgramData 'CommandAudit'
if (-not (Test-Path $shared)) { New-Item -ItemType Directory -Path $shared -Force | Out-Null }
$acl = Get-Acl $shared
$acl.SetAccessRuleProtection($true, $false)
$acl.Access | ForEach-Object { $acl.RemoveAccessRule($_) | Out-Null }
# SYSTEM + Administrators: full control (read/manage the logs)
foreach ($p in 'SYSTEM','Administrators') {
    $acl.AddAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule(
        $p,'FullControl','ContainerInherit,ObjectInherit','None','Allow')))
}
# Authenticated users: may create/append log entries, but not read others' logs
$acl.AddAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule(
    'Authenticated Users','Write','ContainerInherit,ObjectInherit','None','Allow')))
Set-Acl -Path $shared -AclObject $acl
Write-Host "[+] Shared log folder ready (all accounts can log): $shared" -ForegroundColor Green

# --- 0b. Remove any BROKEN or leftover cmd AutoRun (self-heal) ---------------
# A stale cmd.exe AutoRun that points to a file which no longer exists (e.g. an
# old "CmdLogger\cmd-init.bat" from a previous version) makes EVERY cmd window
# print a "cannot find the path" error and can stop Clink from loading, so no
# commands get captured. Clear such entries before we install our own. We only
# touch entries that are clearly broken or from a previous version of this tool;
# any legitimate Clink part of a chained AutoRun is preserved.
foreach ($hive in 'HKLM:\SOFTWARE\Microsoft\Command Processor',
                  'HKCU:\Software\Microsoft\Command Processor') {
    try { $ar = (Get-ItemProperty -Path $hive -Name AutoRun -ErrorAction Stop).AutoRun }
    catch { continue }
    if ([string]::IsNullOrWhiteSpace($ar)) { continue }

    $broken = $false
    if ($ar -match 'CmdLogger|cmd-init\.bat') { $broken = $true }
    foreach ($mm in [regex]::Matches($ar, '"?([A-Za-z]:\\[^"&|]+?\.(?:bat|cmd|exe))"?')) {
        if (-not (Test-Path -LiteralPath $mm.Groups[1].Value)) { $broken = $true }
    }
    if (-not $broken) { continue }

    # Keep only the Clink portion of a chained AutoRun; else drop the value.
    $keep = (($ar -split '\s*&+\s*') | Where-Object { $_ -match 'clink' }) -join ' & '
    if ($keep) {
        Set-ItemProperty -Path $hive -Name AutoRun -Value $keep
        Write-Host "[+] Cleaned a leftover entry from cmd AutoRun ($hive)." -ForegroundColor Green
    } else {
        Remove-ItemProperty -Path $hive -Name AutoRun -ErrorAction SilentlyContinue
        Write-Host "[+] Removed a broken/leftover cmd AutoRun ($hive)." -ForegroundColor Green
    }
}

# --- 0c. Remove leftover folders/files from OLD versions of this tool --------
# Superseded by CommandAudit. Each path is deleted ONLY if it exists. Hard
# guards below make it impossible to delete the current CommandAudit install,
# its live logs, or the folder this installer is running from.
$legacy = @(
    (Join-Path $env:ProgramData  'CmdLogger'),
    (Join-Path $env:ProgramData  'CommandLogger'),
    (Join-Path $env:LOCALAPPDATA 'CmdLogger'),
    'C:\CmdLogger',
    'C:\CommandLogger',
    'C:\CommandRecord',
    'C:\CommandLog',
    'C:\command_log.txt'
)
$here = $PSScriptRoot.TrimEnd('\')
foreach ($p in $legacy) {
    if (-not (Test-Path -LiteralPath $p)) { continue }
    if ($p -match 'CommandAudit')          { continue }   # never the current tool
    if ($p.TrimEnd('\') -ieq $here)        { continue }   # never our own folder
    try {
        Remove-Item -LiteralPath $p -Recurse -Force -ErrorAction Stop
        Write-Host "[+] Removed leftover from an old version: $p" -ForegroundColor Green
    } catch {
        Write-Host "[!] Could not remove $p : $($_.Exception.Message)" -ForegroundColor DarkYellow
    }
}

# --- 1. cmd.exe: Clink autorun for ALL users ---------------------------------
if (-not (Test-Path $lua))      { throw "Missing $lua" }
if (-not (Test-Path $clinkExe)) { throw "Missing $clinkExe" }
& $clinkExe autorun install --allusers | Out-Null
Write-Host "[+] Clink autorun installed for ALL users (cmd built-in capture)." -ForegroundColor Green

# --- 2. PowerShell: machine-wide profile loads the logger --------------------
$allProfile = $PROFILE.AllUsersAllHosts
$dir = Split-Path $allProfile
if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
$load = ". `"$engine`"   # command-audit logger"
$cur  = if (Test-Path $allProfile) { Get-Content $allProfile -Raw } else { '' }
if ($cur -notmatch [regex]::Escape($engine)) {
    Add-Content -LiteralPath $allProfile -Value "`r`n$load`r`n" -Encoding UTF8
    Write-Host "[+] PowerShell logger installed for ALL users." -ForegroundColor Green
} else { Write-Host "[=] PowerShell logger already installed for all users." -ForegroundColor Yellow }

# --- 3. PowerShell Script Block Logging (Event 4104) -------------------------
$sbl = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging'
New-Item -Path $sbl -Force | Out-Null
Set-ItemProperty $sbl -Name EnableScriptBlockLogging -Value 1 -Type DWord
Write-Host "[+] PowerShell Script Block Logging enabled (Event 4104)." -ForegroundColor Green

# --- 4. Process Creation auditing (Event 4688) with command line -------------
auditpol /set /subcategory:"Process Creation" /success:enable /failure:enable | Out-Null
$sys = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Audit'
New-Item -Path $sys -Force | Out-Null
Set-ItemProperty $sys -Name ProcessCreationIncludeCmdLine_Enabled -Value 1 -Type DWord
Write-Host "[+] Process Creation auditing enabled (Event 4688 + command line)." -ForegroundColor Green

Write-Host "`nDONE. Now open a NEW 'dw' shell to activate capture there." -ForegroundColor Cyan
Write-Host "Read everything with:  powershell -File `"$PSScriptRoot\Get-CapturedCommands.ps1`"" -ForegroundColor Cyan
Write-Host "(Run the reader elevated so it can read the 4688 Security log.)" -ForegroundColor DarkCyan
