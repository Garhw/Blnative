@echo off
setlocal
title Splendid - Captured Commands

REM Re-launch elevated if not already admin (marker arg prevents any loop).
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Asking for administrator rights ^(needed to read the command log^)...
    powershell -NoProfile -Command "Start-Process cmd -Verb RunAs -ArgumentList '/k','""%~f0"" elevated'"
    exit /b
)

cls
echo ============================================================
echo   Splendid - commands recorded on this PC
echo ============================================================
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Get-CapturedCommands.ps1"
echo.
echo The results were saved to the text file:
echo    "%~dp0commands.txt"
echo (It is replaced with fresh results each time you run SHOW-COMMANDS.
echo  To open it, double-click OPEN-LOG.cmd.)
echo.
echo ============================================================
echo   Done. This window stays open so you can read it.
echo ============================================================
echo.
pause
