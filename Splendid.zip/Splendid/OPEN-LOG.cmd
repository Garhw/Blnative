@echo off
REM Opens the saved command log (in this same folder) in Notepad. No admin needed.
REM (Run SHOW-COMMANDS.cmd at least once to generate/refresh it.)
set "LOG=%~dp0commands.txt"
if exist "%LOG%" (
    start "" notepad "%LOG%"
) else (
    echo No log yet. Double-click SHOW-COMMANDS.cmd once first ^(tap Yes^), then open this.
    pause
)
