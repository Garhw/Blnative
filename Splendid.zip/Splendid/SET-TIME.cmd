@echo off
setlocal
title Splendid - Set viewing time range

REM Saves your chosen look-back window. SHOW-COMMANDS uses it from now on,
REM and it stays set until you run this again. No admin rights needed.
set "CFGDIR=%LOCALAPPDATA%\CommandAudit"
if not exist "%CFGDIR%" mkdir "%CFGDIR%" >nul 2>nul

cls
echo ============================================================
echo   Splendid - how far back should SHOW-COMMANDS look?
echo ============================================================
echo.
echo   1) Last 20 minutes   (default)
echo   2) Last 1 hour
echo   3) Last 6 hours
echo   4) Last 24 hours
echo   5) Last 7 days
echo   6) Everything (all recorded)
echo   7) Custom - type your own number of minutes
echo.

set "MINS="
set /p "choice=Type 1-7 and press Enter: "

if "%choice%"=="1" set "MINS=20"
if "%choice%"=="2" set "MINS=60"
if "%choice%"=="3" set "MINS=360"
if "%choice%"=="4" set "MINS=1440"
if "%choice%"=="5" set "MINS=10080"
if "%choice%"=="6" set "MINS=0"
if "%choice%"=="7" set /p "MINS=Enter number of minutes: "

REM must be a whole number (0 = everything)
echo %MINS%| findstr /r "^[0-9][0-9]*$" >nul
if errorlevel 1 (
    echo.
    echo Not a valid choice - nothing was changed.
    echo.
    pause
    exit /b
)

> "%CFGDIR%\view_minutes.txt" echo %MINS%

echo.
if "%MINS%"=="0" (
    echo Saved: SHOW-COMMANDS will now show EVERYTHING recorded.
) else (
    echo Saved: SHOW-COMMANDS will now show the last %MINS% minutes.
)
echo This stays set until you run SET-TIME.cmd again.
echo.
pause
