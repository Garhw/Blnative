KEY TYPER  -  "1 key press = 1 letter"
========================================

WHAT IT DOES
  You put your text in a .txt file. When you run KeyTyper and then press keys,
  each key press types the NEXT letter of your text - one at a time, with spaces
  and line breaks kept. It works in any app. Nothing is sent anywhere; it only
  types on your own PC. You do NOT need Python or anything installed.

SETUP (one time)
  1. Unzip this to your Desktop, so you have a folder:
        Desktop\KeyTyper
  2. Open that folder and put your text in  text.txt
     (or drop your own .txt file into the folder - it uses the newest one).

HOW TO RUN  (for DWService / remote-access users)
  IMPORTANT: start it with  Run.bat , NOT the .exe directly. If you run the .exe
  from the DW Shell it starts in a hidden background session and cannot see your
  keys. Run.bat fixes that by launching it into your Screen session.

  From your DW Shell, run this (press Enter):
        "%USERPROFILE%\Desktop\KeyTyper\Run.bat"

  Then:
   - KeyTyper runs INVISIBLY in the background (no window - that is normal).
     Wait about 3 seconds, then switch to your Screen.
   - Click into your app (chat, Word, a form, etc.) and press ANY keys. Each key
     press types the next letter of your text. Hold a key to go fast.
   - It stops on its own when the text is finished.
     To stop early: press  Ctrl + Alt + Q.
   - A small keytyper_log.txt in the folder records the last run (for checking).

  (If you use the PC directly - not remotely - you can just double-click
   KeyTyper.exe instead. Run.bat also works by double-click.)

IF WINDOWS BLOCKS IT
  Because this watches the keyboard and isn't signed, Windows SmartScreen or your
  antivirus may warn (this is normal for this kind of tool and it is safe):
   - "Windows protected your PC": click  More info  ->  Run anyway.
   - If antivirus removes KeyTyper.exe, allow/restore it, or add the KeyTyper
     folder to your antivirus "exclusions", then run again.

NOTES
  - Line breaks become a real Enter. Good for a document or form box. In a chat
    where Enter SENDS the message, each line would send separately - for a chat,
    keep your text on one line.
  - If the Screen window doesn't appear the first time, run Run.bat once more.
