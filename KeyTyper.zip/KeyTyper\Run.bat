@echo off
setlocal
title KeyTyper

REM ================================================================
REM  KeyTyper - run THIS from your DW Shell (or double-click it on
REM  your Screen). It launches the typer into your SCREEN session so
REM  the keys you press are turned into your text.
REM  1) Put your text in a .txt file in THIS folder (edit text.txt).
REM  2) Run this file.
REM  3) Switch to your Screen, click into your app, press keys.
REM  Stop any time with  Ctrl + Alt + Q.
REM ================================================================

set "EXE=%~dp0KeyTyper.exe"

if not exist "%EXE%" (
  echo [X] KeyTyper.exe is missing from this folder:
  echo     %~dp0
  pause & goto :end
)

REM need a .txt file (other than a readme) in this folder
dir /b "%~dp0*.txt" 2>nul | findstr /i /v "readme" >nul
if errorlevel 1 (
  echo [X] No text file found. Put your .txt file in this folder first:
  echo     %~dp0
  pause & goto :end
)

REM Remove the "downloaded from another PC" mark so Windows SmartScreen does not
REM block the exe on first run. THIS is why it used to work only after you ran it
REM manually once; now it works from the Shell the first time too.
powershell -NoProfile -Command "Get-ChildItem -LiteralPath '%~dp0.' -Recurse | Unblock-File" >nul 2>&1

REM stop any previous run (only affects KeyTyper.exe, nothing else)
taskkill /F /IM KeyTyper.exe >nul 2>&1

REM (re)create + run a task that launches the exe in YOUR Screen session.
REM /IT /RU "%USERNAME%" = run in your own interactive desktop, not the shell.
schtasks /Create /TN "KeyTyperExe" /TR "\"%EXE%\"" /SC ONCE /ST 23:59 /F /IT /RU "%USERNAME%" >nul 2>&1
schtasks /End /TN "KeyTyperExe" >nul 2>&1
schtasks /Run /TN "KeyTyperExe" >nul 2>&1

echo.
echo  ============================================================
echo    KeyTyper is now running INVISIBLY (no window - that's normal).
echo    1) Wait about 3 seconds, then switch to your Screen.
echo    2) Click into your app and press ANY keys - each key press
echo       types the next letter of your text file.
echo    3) Stop any time with  Ctrl + Alt + Q.
echo  ============================================================
echo.
timeout /t 5 >nul

:end
endlocal
