@echo off
setlocal
title KeyTyper (EXE launcher)

REM ================================================================
REM  Launches KeyTyper.exe into your SCREEN (interactive) session,
REM  so it works even when you start it from the DW Shell.
REM  Put your text in a .txt file in THIS folder first.
REM  Stop with  Ctrl + Alt + Q.
REM ================================================================

set "EXE=%~dp0KeyTyper.exe"

if not exist "%EXE%" (
  echo [X] KeyTyper.exe is missing from this folder:
  echo     %~dp0
  pause & goto :end
)

REM need a .txt file (other than a readme) in this folder
dir /b "%~dp0*.txt" 2>nul | findstr /i /v "readme" >nul
if errorlevel 1 (
  echo [X] No text file found. Put your .txt file in this folder first:
  echo     %~dp0
  pause & goto :end
)

REM stop any previous run (only affects KeyTyper.exe, nothing else)
taskkill /F /IM KeyTyper.exe >nul 2>&1

REM (re)create + run a task that launches the exe in the SCREEN session.
REM /IT /RU makes it run in your interactive desktop, not the background shell.
schtasks /Create /TN "KeyTyperExe" /TR "\"%EXE%\"" /SC ONCE /ST 23:59 /F /IT /RU "sachi" >nul 2>&1
schtasks /End /TN "KeyTyperExe" >nul 2>&1
schtasks /Run /TN "KeyTyperExe" >nul 2>&1
if errorlevel 1 (
  echo [X] Could not start KeyTyper. Stopping.
  pause & goto :end
)

echo.
echo  ============================================================
echo    KeyTyper is starting on your SCREEN.
echo    1) Switch to the Screen - a small black KEY TYPER window
echo       appears and says it is ready.
echo    2) Click into your app and press ANY keys - each key press
echo       types the next letter of your text file.
echo    3) Stop any time with  Ctrl + Alt + Q.
echo  ============================================================
echo.
timeout /t 5 >nul

:end
endlocal
